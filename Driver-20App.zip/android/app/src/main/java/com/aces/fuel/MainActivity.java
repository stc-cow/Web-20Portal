package com.aces.fuel;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
